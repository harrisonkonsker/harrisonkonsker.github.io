# Premium Study Guide Format — Spec

This document is the **canonical specification** for the study guide format used in this folder. If the build script (`build_premium_study_guide.py`) is missing from a new session, rebuild it from this spec. Do not deviate without the user's approval.

---

## Fonts

- **Calibri** — headers, labels, section titles, table headers, numbers, bullets, eyebrows, callout headers
- **Arial** — body prose, table cells, callout body content, narrative, definitions

Body size: 11pt. Line spacing: 1.15 (1.2 inside narrative paragraphs).

---

## Color palette

| Role | Hex | Usage |
|---|---|---|
| Cardinal | `#8C1515` | Headers, section banners, eyebrow labels, table header rows (text white) |
| Ink | `#1F1F1F` | Body text default |
| Subtle | `#555555` | Captions, subtitles |
| Rule gray | `#C9C9C9` | Horizontal dividers between sections |
| Highlight yellow | `#FFF3CD` | Inline must-not-miss highlight (🔴 tier) |
| MEMORIZE bg | `#FFF8E1` | Warm cream callout background |
| MEMORIZE border | `#E6B800` | Orange left border on MEMORIZE callout |
| TRAP bg | `#FDE8E8` | Warm pink left cell of EXAM TRAP |
| TRAP border | `#C0392B` | Red left border on TRAP cell |
| REALITY bg | `#E6F4EA` | Warm green right cell of EXAM TRAP |
| REALITY border | `#1E8449` | Green left border on REALITY cell |
| BIG PICTURE bg | `#E8F0F7` | Cool blue band for Big Picture and Study Protocol callouts |
| BIG PICTURE border | `#1F4E79` | Navy left border |

---

## Document structure (in order)

### 1. Title block
- 28pt Calibri bold cardinal — lecture title
- 12pt Calibri italic subtle — course name
- Study Protocol callout (cool blue band): "Study Protocol · Read this guide today. Import the Anki deck. First Anki review TOMORROW, not today."
- Horizontal rule

### 2. Part 1 — The Big Picture
- L1 section header: small cardinal eyebrow + 20pt Calibri bold title + horizontal rule
- BIG PICTURE callout (cool blue band) — 5-7 sentence narrative primer
- HIGH-YIELD ORIENTATION — small cardinal label + 6-8 bullet points (cardinal dot bullets)

### 3. Part 2 — Per-Objective Deep Dives
For each LO:
- LO header: 10pt cardinal "LO1" badge + 13pt Calibri bold LO text
- Italic subhead (12pt Calibri bold italic cardinal) — section title
- Narrative paragraphs (Arial 11pt, 1.2 line spacing) with inline emphasis:
  - `**word**` → bold
  - `__word__` → bold + yellow highlight (professor-flagged)
- Comparison tables (when content is matrix-shaped): cardinal header row with white text, alternating row shading, 10pt Arial body
- MEMORIZE callout: warm cream box, orange left border, "MEMORIZE" header in cardinal, arrow bullets (→) with bold term + plain definition
- EXAM TRAPS two-column table: pink "TRAP" cell on left, green "REALITY" cell on right, each with colored left border

### 4. Part 3 — Integration
- TOP 10 MUST-KNOW: cardinal label + numbered list with bold cardinal numbers
- Master comparison tables (when relevant)
- ANKI CARDS IN THIS DECK: cardinal label + per-LO groupings showing card stems (cloze stripped)

---

## Inline emphasis tiers

| Tier | Markup | Visual |
|---|---|---|
| 🔴 Must-not-miss / professor-flagged | `__text__` | Bold + yellow highlight |
| 🟡 Anki concept | `**text**` | Bold |
| ⚪ Context | (none) | Plain |

Bold density target: ≤30% of body text. Highlight density target: ≤10%.

---

## JSON input schema

Per-lecture content lives at `outputs/micro_decks/<lecture>.json`:

```json
{
  "lecture": "...",
  "course": "...",
  "los": { "LO1": "verbatim text", ... },
  "big_picture": "5-7 sentence prose primer",
  "orientation": [ "bullet 1", "bullet 2", ... ],
  "sections": [
    {
      "lo": "LO1",
      "title": "italic subhead",
      "narrative": "multi-paragraph prose with **bold** and __highlight__ markers",
      "memorize": [ {"term": "...", "def": "..."}, ... ],
      "traps": [ {"trap": "...", "reality": "..."}, ... ]
    }
  ],
  "top10": [ "item 1", ... ],
  "cards": [ ... ]
}
```

Enriched JSON (with bold/highlight markers applied) lives at `<lecture>.enriched.json`. Pass the enriched JSON explicitly to the renderer if you ran the enrichment step.

---

## Optional `extras` parameter

```json
{
  "tables": {
    "LO2E": [
      {
        "title": "Endemic fungi 5-way matrix",
        "headers": ["Organism", "Region", "Tissue form", "Clinical", "Host"],
        "rows": [ [...], [...] ]
      }
    ]
  },
  "master_tables": [
    { "title": "...", "headers": [...], "rows": [...] }
  ]
}
```

Tables are dropped inline after the narrative of the matching LO. Master tables appear in Part 3.

---

## Anti-patterns (do not do these)

- Plain Calibri paragraphs with no callouts → the old format, ugly, do not produce
- Forgetting MEMORIZE/TRAP callouts when the data has them
- Putting comparison content in prose when a table would be clearer
- Using `<b>...</b>` HTML tags (only Anki cards use HTML; the docx renderer uses `**...**` markers)
- Skipping the LO header — every section must have one
- Changing fonts mid-document (only the two: Calibri headers + Arial body)
- Omitting the Study Protocol banner

---

## Build command

```bash
python3 build_premium_study_guide.py <input.json> <output.docx>
```

