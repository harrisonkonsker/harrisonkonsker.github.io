"""
Premium study guide docx builder — pilot on TB+Fungi.
Pulls cards/sections from micro_decks/<lecture>.json and renders a high-design docx with:
  - Mixed font (Calibri headers, Georgia body)
  - Cardinal-red accent + tiered emphasis (red highlight / bold / plain)
  - Callout boxes (MEMORIZE = yellow band; TRAPS = red/green split; BIG PICTURE = teal band)
  - Comparison tables (endemic fungi matrix, TB drug table, etc. — supplied by extras)
  - 1.15 line spacing, narrow margins, arrow bullets for mechanism chains
"""
import json, re, sys
from pathlib import Path
from copy import deepcopy
from docx import Document
from docx.shared import Pt, Inches, RGBColor, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.enum.table import WD_ALIGN_VERTICAL, WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn, nsmap
from docx.oxml import OxmlElement


# ===== Fonts =====
HEADER_FONT = "Calibri"    # display / headers / labels
BODY_FONT   = "Arial"      # body prose / table cells / callouts

# ===== Color palette =====
CARDINAL = "8C1515"        # Stanford cardinal red — headers + accents
INK = "1F1F1F"             # body text
SUBTLE = "555555"          # captions
RULE_GRAY = "C9C9C9"       # divider lines
HIGHLIGHT_YELLOW = "FFF3CD"  # professor-flagged
MEMORIZE_BG = "FFF8E1"     # warm cream
MEMORIZE_BORDER = "E6B800"
TRAP_BG = "FDE8E8"         # warm pink
TRAP_BORDER = "C0392B"
REALITY_BG = "E6F4EA"      # warm green
REALITY_BORDER = "1E8449"
BIG_PIC_BG = "E8F0F7"      # cool blue
BIG_PIC_BORDER = "1F4E79"
MECH_BG = "F2F2F2"         # gray for mechanism chains


# ===== Low-level XML helpers =====
def set_cell_bg(cell, hex_color: str):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_color)
    tcPr.append(shd)


def set_cell_border(cell, left=None, right=None, top=None, bottom=None, size=12):
    """side: dict like {'sz': 12, 'color': 'C0392B'} or None."""
    tcPr = cell._tc.get_or_add_tcPr()
    tcBorders = OxmlElement("w:tcBorders")
    for side_name, side_val in [("top", top), ("left", left), ("bottom", bottom), ("right", right)]:
        b = OxmlElement(f"w:{side_name}")
        if side_val:
            b.set(qn("w:val"), "single")
            b.set(qn("w:sz"), str(side_val.get("sz", size)))
            b.set(qn("w:color"), side_val.get("color", "auto"))
        else:
            b.set(qn("w:val"), "nil")
        tcBorders.append(b)
    tcPr.append(tcBorders)


def add_horizontal_rule(doc, color=RULE_GRAY, size=6):
    p = doc.add_paragraph()
    pPr = p._p.get_or_add_pPr()
    pBdr = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), str(size))
    bottom.set(qn("w:space"), "1")
    bottom.set(qn("w:color"), color)
    pBdr.append(bottom)
    pPr.append(pBdr)
    return p


def set_para_spacing(p, before=4, after=4, line_rule=WD_LINE_SPACING.MULTIPLE, line=1.15):
    pf = p.paragraph_format
    pf.space_before = Pt(before)
    pf.space_after = Pt(after)
    pf.line_spacing = line
    pf.line_spacing_rule = line_rule


def style_run(run, *, font=None, size=None, bold=False, italic=False, color=None, highlight=None):
    if font: run.font.name = font
    if size: run.font.size = Pt(size)
    run.font.bold = bold
    run.font.italic = italic
    if color: run.font.color.rgb = RGBColor.from_string(color)
    if highlight:
        rPr = run._element.get_or_add_rPr()
        shd = OxmlElement("w:shd")
        shd.set(qn("w:val"), "clear")
        shd.set(qn("w:color"), "auto")
        shd.set(qn("w:fill"), highlight)
        rPr.append(shd)


# ===== Higher-level styled paragraphs =====
def title_block(doc, lecture, course):
    # Title
    p = doc.add_paragraph()
    set_para_spacing(p, before=0, after=2)
    r = p.add_run(lecture)
    style_run(r, font=HEADER_FONT, size=28, bold=True, color=CARDINAL)

    # Subtitle
    sub = doc.add_paragraph()
    set_para_spacing(sub, before=0, after=8)
    r = sub.add_run(course)
    style_run(r, font=HEADER_FONT, size=12, italic=True, color=SUBTLE)

    # Study protocol callout
    tbl = doc.add_table(rows=1, cols=1)
    tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = tbl.rows[0].cells[0]
    set_cell_bg(cell, BIG_PIC_BG)
    set_cell_border(cell, left={"sz": 24, "color": BIG_PIC_BORDER})
    cp = cell.paragraphs[0]
    set_para_spacing(cp, before=4, after=4)
    r = cp.add_run("Study Protocol  ")
    style_run(r, font=HEADER_FONT, size=11, bold=True, color=BIG_PIC_BORDER)
    r2 = cp.add_run("· Read this guide today. Import the Anki deck. First Anki review TOMORROW, not today.")
    style_run(r2, font=BODY_FONT, size=11, color=INK)
    add_horizontal_rule(doc)


def section_header(doc, label, text):
    """L1 section header — large, cardinal, with eyebrow label and bottom rule."""
    eyebrow = doc.add_paragraph()
    set_para_spacing(eyebrow, before=12, after=0)
    r = eyebrow.add_run(label.upper())
    style_run(r, font=HEADER_FONT, size=9, bold=True, color=CARDINAL)

    h = doc.add_paragraph()
    set_para_spacing(h, before=0, after=2)
    r = h.add_run(text)
    style_run(r, font=HEADER_FONT, size=20, bold=True, color=INK)
    add_horizontal_rule(doc)


def lo_header(doc, lo_id, lo_text):
    """L2 LO subsection header."""
    p = doc.add_paragraph()
    set_para_spacing(p, before=14, after=0)
    r = p.add_run(lo_id)
    style_run(r, font=HEADER_FONT, size=10, bold=True, color=CARDINAL)
    r2 = p.add_run(f"   {lo_text}")
    style_run(r2, font=HEADER_FONT, size=13, bold=True, color=INK)


def subhead(doc, text):
    """L3 subhead — italic title for narrative section."""
    p = doc.add_paragraph()
    set_para_spacing(p, before=8, after=2)
    r = p.add_run(text)
    style_run(r, font=HEADER_FONT, size=12, bold=True, italic=True, color=CARDINAL)


# Inline bold emphasis pattern: **word** → bold; __word__ → highlighted yellow
INLINE_BOLD_RE = re.compile(r"\*\*(.+?)\*\*")
INLINE_HL_RE = re.compile(r"__(.+?)__")

def write_styled_run(p, text, *, base_font=BODY_FONT, base_size=11, base_color=INK):
    """Parse **bold** and __highlight__ markers and write styled runs into paragraph p."""
    # First pass: split by highlight, then within each segment split by bold
    pos = 0
    pieces = []
    # collect non-overlapping markers
    spans = []
    for m in INLINE_BOLD_RE.finditer(text):
        spans.append(("bold", m.start(), m.end(), m.group(1)))
    for m in INLINE_HL_RE.finditer(text):
        spans.append(("hl", m.start(), m.end(), m.group(1)))
    spans.sort(key=lambda s: s[1])
    for kind, s, e, content in spans:
        if pos < s:
            pieces.append(("plain", text[pos:s]))
        pieces.append((kind, content))
        pos = e
    if pos < len(text):
        pieces.append(("plain", text[pos:]))

    for kind, content in pieces:
        if kind == "plain":
            r = p.add_run(content)
            style_run(r, font=base_font, size=base_size, color=base_color)
        elif kind == "bold":
            r = p.add_run(content)
            style_run(r, font=base_font, size=base_size, color=base_color, bold=True)
        elif kind == "hl":
            r = p.add_run(content)
            style_run(r, font=base_font, size=base_size, color=base_color, bold=True, highlight=HIGHLIGHT_YELLOW)


def narrative_paragraph(doc, text):
    p = doc.add_paragraph()
    set_para_spacing(p, before=2, after=6, line=1.2)
    write_styled_run(p, text)


def memorize_callout(doc, items):
    """Callout: warm cream bg, left orange border, MEMORIZE header in red, items as styled bullets."""
    tbl = doc.add_table(rows=1, cols=1)
    cell = tbl.rows[0].cells[0]
    set_cell_bg(cell, MEMORIZE_BG)
    set_cell_border(cell, left={"sz": 24, "color": MEMORIZE_BORDER})

    h = cell.paragraphs[0]
    set_para_spacing(h, before=2, after=4)
    r = h.add_run("MEMORIZE")
    style_run(r, font=HEADER_FONT, size=11, bold=True, color=CARDINAL)

    for item in items:
        p = cell.add_paragraph()
        set_para_spacing(p, before=0, after=2)
        r = p.add_run("→  ")
        style_run(r, font=HEADER_FONT, size=11, bold=True, color=MEMORIZE_BORDER)
        rt = p.add_run(item["term"])
        style_run(rt, font=BODY_FONT, size=11, bold=True, color=INK)
        rd = p.add_run(f" — {item['def']}")
        style_run(rd, font=BODY_FONT, size=11, color=INK)


def trap_callout(doc, traps):
    """Two-column table: TRAP (pink) | REALITY (green) for each pair."""
    if not traps: return
    label = doc.add_paragraph()
    set_para_spacing(label, before=8, after=2)
    r = label.add_run("⚠  EXAM TRAPS")
    style_run(r, font=HEADER_FONT, size=11, bold=True, color=TRAP_BORDER)

    tbl = doc.add_table(rows=len(traps), cols=2)
    tbl.autofit = False
    tbl.columns[0].width = Inches(3.0)
    tbl.columns[1].width = Inches(3.0)
    for i, t in enumerate(traps):
        c1, c2 = tbl.rows[i].cells
        for c, bg, border in [(c1, TRAP_BG, TRAP_BORDER), (c2, REALITY_BG, REALITY_BORDER)]:
            set_cell_bg(c, bg)
            set_cell_border(c, left={"sz": 24, "color": border})

        # TRAP cell
        p = c1.paragraphs[0]
        set_para_spacing(p, before=2, after=2)
        r = p.add_run("TRAP  ")
        style_run(r, font=HEADER_FONT, size=10, bold=True, color=TRAP_BORDER)
        rt = p.add_run(t["trap"])
        style_run(rt, font=BODY_FONT, size=10, color=INK)

        # REALITY cell
        p = c2.paragraphs[0]
        set_para_spacing(p, before=2, after=2)
        r = p.add_run("REALITY  ")
        style_run(r, font=HEADER_FONT, size=10, bold=True, color=REALITY_BORDER)
        rr = p.add_run(t["reality"])
        style_run(rr, font=BODY_FONT, size=10, color=INK)


def big_picture_block(doc, header, body):
    """Teal-tinted block for big-picture summaries."""
    tbl = doc.add_table(rows=1, cols=1)
    cell = tbl.rows[0].cells[0]
    set_cell_bg(cell, BIG_PIC_BG)
    set_cell_border(cell, left={"sz": 24, "color": BIG_PIC_BORDER})

    h = cell.paragraphs[0]
    set_para_spacing(h, before=2, after=4)
    r = h.add_run(header.upper())
    style_run(r, font=HEADER_FONT, size=11, bold=True, color=BIG_PIC_BORDER)

    for para in body.split("\n\n"):
        p = cell.add_paragraph()
        set_para_spacing(p, before=0, after=4, line=1.2)
        write_styled_run(p, para.strip())


def comparison_table(doc, headers, rows, *, title=None):
    """Styled comparison table with cardinal header row, alternating row shading."""
    if title:
        p = doc.add_paragraph()
        set_para_spacing(p, before=8, after=2)
        r = p.add_run(title.upper())
        style_run(r, font=HEADER_FONT, size=10, bold=True, color=CARDINAL)

    n_cols = len(headers)
    tbl = doc.add_table(rows=len(rows) + 1, cols=n_cols)
    tbl.autofit = True
    # Header row
    for j, h in enumerate(headers):
        c = tbl.rows[0].cells[j]
        set_cell_bg(c, CARDINAL)
        cp = c.paragraphs[0]
        set_para_spacing(cp, before=2, after=2)
        r = cp.add_run(h)
        style_run(r, font=HEADER_FONT, size=10, bold=True, color="FFFFFF")
    # Body rows
    for i, row in enumerate(rows):
        for j, val in enumerate(row):
            c = tbl.rows[i + 1].cells[j]
            if i % 2 == 0:
                set_cell_bg(c, "F7F7F7")
            cp = c.paragraphs[0]
            set_para_spacing(cp, before=1, after=1)
            write_styled_run(cp, str(val), base_font=BODY_FONT, base_size=10)


def orientation_bullets(doc, items):
    p = doc.add_paragraph()
    set_para_spacing(p, before=6, after=2)
    r = p.add_run("HIGH-YIELD ORIENTATION")
    style_run(r, font=HEADER_FONT, size=10, bold=True, color=CARDINAL)
    for item in items:
        bp = doc.add_paragraph()
        set_para_spacing(bp, before=0, after=2)
        r = bp.add_run("•  ")
        style_run(r, font=HEADER_FONT, size=11, bold=True, color=CARDINAL)
        write_styled_run(bp, item)


def numbered_top_facts(doc, items):
    p = doc.add_paragraph()
    set_para_spacing(p, before=8, after=4)
    r = p.add_run("TOP 10 MUST-KNOW")
    style_run(r, font=HEADER_FONT, size=10, bold=True, color=CARDINAL)
    for i, item in enumerate(items, 1):
        bp = doc.add_paragraph()
        set_para_spacing(bp, before=0, after=2)
        r = bp.add_run(f"{i:>2}.  ")
        style_run(r, font=HEADER_FONT, size=11, bold=True, color=CARDINAL)
        write_styled_run(bp, item)


def anki_card_preview(doc, cards_by_lo, los):
    p = doc.add_paragraph()
    set_para_spacing(p, before=12, after=2)
    r = p.add_run("ANKI CARDS IN THIS DECK")
    style_run(r, font=HEADER_FONT, size=10, bold=True, color=CARDINAL)

    # Helper to strip cloze syntax
    cloze_re = re.compile(r"\{\{c\d+::([^:}]+)(?:::[^}]+)?\}\}")
    html_re = re.compile(r"<[^>]+>")
    def strip(s):
        s = cloze_re.sub(lambda m: m.group(1), s)
        s = html_re.sub("", s)
        return s

    for lo in cards_by_lo:
        lh = doc.add_paragraph()
        set_para_spacing(lh, before=4, after=2)
        r = lh.add_run(lo)
        style_run(r, font=HEADER_FONT, size=11, bold=True, color=CARDINAL)
        r2 = lh.add_run(f"  {los.get(lo, '')}")
        style_run(r2, font=HEADER_FONT, size=11, italic=True, color=SUBTLE)
        for c in cards_by_lo[lo]:
            bp = doc.add_paragraph()
            set_para_spacing(bp, before=0, after=1)
            r = bp.add_run("·  ")
            style_run(r, font=BODY_FONT, size=10, color=SUBTLE)
            rt = bp.add_run(strip(c["text"]))
            style_run(rt, font=BODY_FONT, size=10, color=INK)


# ===== Page setup =====
def configure_page(doc):
    section = doc.sections[0]
    section.left_margin = Cm(2.0)
    section.right_margin = Cm(2.0)
    section.top_margin = Cm(2.0)
    section.bottom_margin = Cm(2.0)
    # Default font for the doc
    style = doc.styles["Normal"]
    style.font.name = "Georgia"
    style.font.size = Pt(11)


# ===== Main render =====
def render_premium(data: dict, out_path: Path, extras: dict | None = None):
    extras = extras or {}
    doc = Document()
    configure_page(doc)

    los = data["los"]

    # ===== Title =====
    title_block(doc, data["lecture"], data.get("course", ""))

    # ===== Part 1: Big Picture + Orientation =====
    section_header(doc, "Part 1", "The Big Picture")
    big_picture_block(doc, "BIG PICTURE", data["big_picture"])
    orientation_bullets(doc, data.get("orientation", []))

    # ===== Per-LO deep dives =====
    section_header(doc, "Part 2", "Per-Objective Deep Dives")
    for sec in data["sections"]:
        lo = sec["lo"]
        lo_header(doc, lo, los.get(lo, ""))
        if sec.get("title"):
            subhead(doc, sec["title"])

        # Narrative
        for para in (sec.get("narrative") or "").split("\n\n"):
            if para.strip():
                narrative_paragraph(doc, para.strip())

        # If extras has a table for this LO, drop it inline
        if extras.get("tables", {}).get(lo):
            for t in extras["tables"][lo]:
                comparison_table(doc, t["headers"], t["rows"], title=t.get("title"))

        # Memorize
        if sec.get("memorize"):
            memorize_callout(doc, sec["memorize"])

        # Traps
        if sec.get("traps"):
            trap_callout(doc, sec["traps"])

    # ===== Part 3: Integration =====
    section_header(doc, "Part 3", "Integration")
    if data.get("top10"):
        numbered_top_facts(doc, data["top10"])

    # Endemic fungi master table (extras-driven)
    if extras.get("master_tables"):
        for mt in extras["master_tables"]:
            comparison_table(doc, mt["headers"], mt["rows"], title=mt.get("title"))

    # Anki card preview
    cards_by_lo = {}
    for c in data.get("cards", []):
        cards_by_lo.setdefault(c["lo"], []).append(c)
    if cards_by_lo:
        anki_card_preview(doc, cards_by_lo, los)

    doc.save(str(out_path))


# ===== Example extras (TB+Fungi) — delete or replace for your own lecture =====
EXAMPLE_EXTRAS = {
    "tables": {
        "LO2E": [
            {
                "title": "Endemic fungi 5-way matrix",
                "headers": ["Organism", "Endemic region", "Tissue form", "Clinical signature", "Host risk"],
                "rows": [
                    ["**Coccidioides**", "Arid SW USA, NW Mexico", "**Spherule + endospores**", "Valley Fever; chronic pneumonia; EN + migratory arthralgias; eosinophilic meningitis", "Filipino, African American, pregnancy"],
                    ["**Histoplasma**", "Ohio + Mississippi River valleys; bird/bat droppings", "**Small yeast inside histiocytes**", "Self-limited or chronic pneumonia (TB-like); disseminates in AIDS/anti-TNF", "T-cell deficiency"],
                    ["**Blastomyces**", "Upper Midwest, Great Lakes", "**Broad-based budding yeast**", "Chronic pneumonia + skin + bone lesions", "Outdoor exposure"],
                    ["**Paracoccidioides**", "Central + South America", "**Captain's wheel** multiple budding", "Chronic mucocutaneous lesions; males >> females", "Rural agricultural workers"],
                    ["**Sporothrix**", "No endemic region; decaying vegetation", "Cigar-shaped yeast", "**Sporotrichoid nodular lymphangitis** — skin nodules ascending lymphatics", "Skin inoculation (rose gardener)"],
                ],
            },
        ],
        "LO4TB": [
            {
                "title": "First-line TB drugs — mechanism + signature toxicity",
                "headers": ["Drug", "Mechanism", "Signature side effect", "Notes"],
                "rows": [
                    ["**Isoniazid (INH)**", "Blocks mycolic acid synthesis", "Hepatitis · peripheral neuropathy", "Used for LTBI AND active TB. Give B6 to prevent neuropathy."],
                    ["**Rifampin (RIF)**", "Binds RNA polymerase", "Hepatitis · orange body fluids", "Major CYP450 inducer → many drug interactions"],
                    ["**Pyrazinamide (PZA)**", "Disrupts membrane in acidic environments", "Hepatitis · hyperuricemia", "Kills slow-growing bacilli in granulomas. M. bovis intrinsically resistant."],
                    ["**Ethambutol (EMB)**", "Blocks arabinogalactan polymerization", "**Optic neuritis** (color vision loss)", "Check color vision at baseline + during therapy"],
                ],
            },
            {
                "title": "MDR vs XDR TB",
                "headers": ["Term", "Resistance pattern"],
                "rows": [
                    ["**MDR-TB**", "INH + RIF"],
                    ["**XDR-TB**", "MDR + fluoroquinolone + one injectable (kanamycin / amikacin / capreomycin)"],
                ],
            },
        ],
    },
    "master_tables": [
        {
            "title": "TB exposure → infection → disease flow (90/10 rule)",
            "headers": ["Stage", "Fraction", "Key clinical features"],
            "rows": [
                ["Exposed → infected", "Minority of those exposed", "Depends on infectiousness of source + exposure + environment"],
                ["**Latent TB infection (LTBI)**", "~90% of infected", "Asymptomatic, non-contagious, TST/IGRA positive, CXR may show Ghon/Ranke complex"],
                ["**Active TB disease**", "~10% of infected (half within 2 yr, half over lifetime)", "Cough + hemoptysis + night sweats + weight loss + upper-lobe cavitary lesion"],
                ["HIV-positive host", "**~10% per YEAR** (~30× normal)", "Highest reactivation risk. Also high: transplant, anti-TNF-α, long-term steroids, malnutrition"],
            ],
        },
    ],
}


# ===== Entry point =====
if __name__ == "__main__":
    """
    Usage:
        python build_premium_study_guide.py <input.json> <output.docx>

    Reads a lecture JSON, renders the premium study guide to the output .docx path.
    See SKILL.md for the JSON schema.
    """
    if len(sys.argv) < 3:
        print("Usage: python build_premium_study_guide.py <input.json> <output.docx>")
        sys.exit(1)

    in_path = Path(sys.argv[1])
    out_path = Path(sys.argv[2])
    out_path.parent.mkdir(exist_ok=True, parents=True)

    data = json.loads(in_path.read_text())
    extras = data.pop("extras", {})  # Optional: extras can live inside the JSON
    render_premium(data, out_path, extras=extras)
    print(f"✓ {out_path}")
