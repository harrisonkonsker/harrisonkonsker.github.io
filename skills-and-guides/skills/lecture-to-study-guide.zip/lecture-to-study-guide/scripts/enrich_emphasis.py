"""
Auto-apply **bold** and __highlight__ markers to a deck JSON narrative.

Pass a list of highlight phrases (🔴 must-not-miss) and bold phrases (🟡 Anki concepts).
The script scans every narrative field and wraps the first occurrence of each phrase
in the appropriate marker. Bold matches inside __...__ are skipped.

Usage:
    python enrich_emphasis.py <input.json> <output.json> [--bold "phrase1,phrase2"] [--hl "phrase3"]

Or import:
    from enrich_emphasis import apply_markers
    text = apply_markers("Aspergillus is a mold", bold=["Aspergillus"], highlight=[])
"""
import json, re, sys, argparse
from pathlib import Path


def apply_markers(text: str, *, bold: list[str], highlight: list[str]) -> str:
    if not text:
        return text
    # Highlights first (longest match first to avoid partial overlaps)
    for phrase in sorted(highlight, key=len, reverse=True):
        pattern = re.compile(rf"(?<!_)(?<!\*)({re.escape(phrase)})(?!_)(?!\*)", re.IGNORECASE)
        text = pattern.sub(r"__\1__", text, count=1)  # first occurrence only
    # Bold next (skip matches inside __...__)
    for phrase in sorted(bold, key=len, reverse=True):
        pattern = re.compile(rf"(?<!_)(?<!\*)\b({re.escape(phrase)})\b(?![_*])", re.IGNORECASE)
        parts = re.split(r"(__[^_]+__)", text)
        for i in range(len(parts)):
            if parts[i].startswith("__") and parts[i].endswith("__"):
                continue
            parts[i] = pattern.sub(lambda m: f"**{m.group(1)}**", parts[i], count=2)
        text = "".join(parts)
    return text


def enrich_deck(data: dict, *, bold: list[str], highlight: list[str]) -> dict:
    data["big_picture"] = apply_markers(data.get("big_picture", ""), bold=bold, highlight=highlight)
    data["orientation"] = [apply_markers(x, bold=bold, highlight=highlight) for x in data.get("orientation", [])]
    for sec in data.get("sections", []):
        sec["narrative"] = apply_markers(sec.get("narrative", ""), bold=bold, highlight=highlight)
    data["top10"] = [apply_markers(x, bold=bold, highlight=highlight) for x in data.get("top10", [])]
    return data


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("--bold", default="", help="Comma-separated list of phrases to bold")
    ap.add_argument("--hl", default="", help="Comma-separated list of phrases to highlight")
    args = ap.parse_args()

    bold = [p.strip() for p in args.bold.split(",") if p.strip()]
    highlight = [p.strip() for p in args.hl.split(",") if p.strip()]

    data = json.loads(Path(args.input).read_text())
    enriched = enrich_deck(data, bold=bold, highlight=highlight)
    Path(args.output).write_text(json.dumps(enriched, indent=2, ensure_ascii=False))
    print(f"✓ {args.output}")
