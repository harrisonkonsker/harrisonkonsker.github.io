---
name: anki-flashcard-creator
description: >
  Create study guides and Anki flashcard decks (.apkg) from medical lecture PDFs
  using the L2-first Stanford Med workflow. Use this skill whenever the user uploads
  a lecture PDF and wants flashcards, Anki cards, study materials, study guides,
  or mentions "Anki" in any way. Also trigger when the user wants to cross-reference
  lecture cards against board material, remove duplicates, rebuild an existing deck,
  or do a Week 1 Review of leech cards. This skill generates an interactive HTML
  study guide as a first-pass learning tool, then derives Anki cards directly from
  the study guide. Outputs both an .html study guide and a ready-to-import .apkg file.
---

# Medical Lecture Study Pipeline — v5.7

## ⛔ ANTI-HALLUCINATION RULE (OVERRIDES EVERYTHING)

**Every fact, concept, drug name, trial name, mechanism, and statistic in the study guide and Anki deck MUST come from a specific, identifiable slide in the uploaded lecture PDF.** If a concept is not visually present on any slide, it does NOT exist for purposes of this pipeline — even if you know it's medically correct. Your medical background knowledge is irrelevant. You are a transcription-and-teaching tool, not a textbook.

**What this means in practice:**
1. **NO supplementary content.** If the lecture doesn't mention cancer vaccines, there is no cancer vaccines card — period. Even if a complete immunotherapy lecture "should" cover cancer vaccines.
2. **NO inferred slides.** If you can't point to a specific slide number where a concept appears, you cannot card it or include it in the study guide.
3. **NO fabricated slide numbers.** The SLIDE_NUM field in each card is the literal PDF page number where the concept is taught. If you assign slide 4 to a card, slide 4 in the PDF must actually contain that content.
4. **NO background fill.** Do not "round out" a topic with your training knowledge. If the lecture covers checkpoints but not CAR-T manufacturing, you cover checkpoints only.

**Why this rule exists:** LLMs hallucinate by generating plausible-sounding medical content from training data. In a flashcard pipeline, this is catastrophic — students study fabricated content believing it was taught in lecture, then face exam questions based on what was actually taught. The slide PDF is the single source of truth. Nothing else.

**Verification:** After generating all cards, you MUST re-read every referenced slide to confirm the card content actually appears on that slide. This is Phase 3E (Slide-Content Verification).

---

## Philosophy

This pipeline transforms medical lectures into two tightly coupled outputs:

1. **Study Guide (.html)** — An interactive, narrative first-pass with enforced retrieval practice. NOT a passive document. Designed for 15-20 minutes per lecture hour. Covers EVERYTHING in the lecture for comprehension.
2. **Anki Deck (.apkg)** — A LEAN set of flashcards derived FROM the study guide, targeting ONLY concepts that directly answer the stated Learning Objectives. L2-first approach.

**The study guide is comprehensive. The Anki deck is ruthlessly selective.**

The study guide and the Anki deck serve different purposes:
- **Study guide** = understand everything (broad, narrative, engaging)
- **Anki deck** = retrieve the 25-35 concepts that answer the LOs under exam pressure (narrow, high-yield only)

### The High-Yield Filter (Non-Negotiable)

Medical students are drowning in cards. A single lecture generating 50-60 cards across 4-5 courses means 200+ new cards/week, and Anki reviews compound. This pipeline is designed for a **pass/fail curriculum** where the goal is deep understanding of high-yield material, not exhaustive memorization of every detail.

**The Yield Test — every card must pass ALL THREE:**

1. **LO-Direct Test:** Does this card directly answer one of the stated Learning Objectives? If the concept isn't needed to answer an LO, it stays in the study guide but does NOT get a card.
2. **Redundancy Test:** Is this concept already tested by another card? If an L2 card about "Na/K pump failure → cellular swelling" already exists, you do NOT also make an L1 card for "hydropic change" — that's double-carding the same knowledge.
3. **Derivability Test:** Can the student derive this fact from a relationship they already have a card for? If yes → no separate card needed. The study guide teaches it; the L2 card tests the relationship that makes it retrievable.

**Target: 25-35 cards per lecture hour.** If you exceed 35, go back and apply the three tests more aggressively.

**What gets cut (goes in study guide only, NOT in Anki):**
- Vocabulary words the student will absorb from context (e.g., "anthracosis," "serous exudate")
- L1 facts that are already embedded in an L2 relationship card
- Content from sections not covered by a stated LO (unless it's a universally high-yield concept like cell regeneration categories)
- Detailed process steps beyond what the LO asks (e.g., full fever mechanism when the LO only asks to "distinguish acute from chronic inflammation")
- Overlapping cards that test the same concept from slightly different angles

**What stays:**
- Every L2 card that directly answers "how" or "why" within an LO
- The ~3-5 truly irreducible L1 facts per lecture that cannot be embedded in any relationship (cardinal signs, pathognomonic findings, classic lists)
- 1-2 L3/L3-NR process cards for genuinely important pathways

### Core Design Rules (Non-Negotiable)

1. **High-yield filter applied to EVERY card** — the three tests above before any card is written
2. **Prediction prompts are ENFORCED** — answers hidden behind click/tap, not visible on screen
3. **No analogy dependence** — study guide uses intuitive analogies; card Extra uses clinical restatement
4. **Spacing is mandatory** — "Read today, review tomorrow" explicitly delivered with outputs
5. **Interleaving built in** — bridging paragraphs connect objectives; practice questions cross LOs
6. **Tiered emphasis** — three visual levels, not just bold/not-bold
7. **Bold density cap: 40%** — if more than 40% of a section is bolded, you're over-carding
8. **Mechanism maps integrated into narrative** — no standalone redundant section
9. **Extra field = "Conceptual Bridge"** — intuition→precision, never a "dumbed down" restatement
10. **Week 1 Review protocol** — iterative improvement from leech cards
11. **Practice questions follow vignette taxonomy** — not recall questions in disguise
12. **25-35 card cap per lecture hour** — if you exceed this, you're not filtering hard enough

---

## Pipeline Overview

```
INPUT: Lecture PDF + optional transcript
         │
         ▼
   ┌─────────────────────────┐
   │  PHASE 1: Section Map   │  Extract LOs, classify slides,
   │  & Signal Extraction    │  extract professor emphasis signals
   └─────────┬───────────────┘
             │
             ▼
   ┌─────────────────────────┐
   │  PHASE 2: Study Guide   │  Interactive HTML with enforced
   │  Generation (.html)     │  retrieval, tiered emphasis,
   │                         │  integrated mechanisms
   └─────────┬───────────────┘
             │
             ▼
   ┌─────────────────────────┐
   │  PHASE 3: Card          │  Cards DERIVED from study guide
   │  Generation             │  Conceptual bridges (not same analogy)
   └─────────┬───────────────┘
             │
             ▼
   ┌─────────────────────────┐
   │  PHASE 4: Pipeline      │  Run anki_pipeline_v2_1.py
   │  & Delivery             │  Deliver .html + .apkg + spacing note
   └─────────────────────────┘
             │
         [5-7 days later]
             │
             ▼
   ┌─────────────────────────┐
   │  PHASE 5: Week 1 Review │  User reports leech cards
   │  (On Request)           │  Regenerate problem sections
   └─────────────────────────┘
```

---

## PHASE 1: Section Map & Signal Extraction

### Step 1A: Extract Learning Objectives

**⚠️ VERBATIM LO EXTRACTION (MANDATORY):**
Before building the section map, locate the Learning Objectives slide (typically slides 2-5) and copy each LO **exactly as written on the slide**. Do NOT paraphrase, infer, summarize, or generate LOs from lecture content. Each card's LO field (field 5 in the pipe-delimited format) must use the **exact verbatim text** from this slide. If no LO slide exists, flag this to the user and ask them to provide the LOs before proceeding. Fabricating plausible-sounding LOs is a critical error — the LO field drives how students organize their review and must match what the professor stated.

**⚠️ COMPLETE SLIDE MAP (MANDATORY):**
You MUST read EVERY slide in the PDF (all pages) and produce a numbered slide-by-slide content summary BEFORE writing any study guide text or flashcards. Output this as:

```
SLIDE MAP (verified against PDF):
  Slide 1: [1-line description of what's actually on the slide]
  Slide 2: [1-line description]
  ...
  Slide N: [1-line description]
```

This slide map is the ONLY content inventory you may draw from. Any concept not traceable to a specific slide number in this map CANNOT appear in the study guide or flashcards. Present this slide map to the user before proceeding to Phase 2.

Read every slide. Build a section map BEFORE writing anything:

```
================================================================================
SECTION 01: <TITLE>
Slides: X–Y
Learning Objective(s): <LO text>
Slide Classification:
  • Teaching slides (diagrams/pathways/clinical images): [slide numbers]
  • Text slides (bullet points professor talks over): [slide numbers]
  • Title/transition slides: [slide numbers] → SKIP
================================================================================
```

### Step 1B: Classify Slides

| Type | Description | Use in Study Guide | Use in Anki |
|------|-------------|-------------------|-------------|
| **Teaching slide** | Diagram, pathway, clinical photo, histology | Embed at exact relevant moment | Attach to corresponding cards |
| **Text slide** | Bullet points, definitions, lists | Extract content, don't embed image | Content feeds into cards |
| **Title/transition** | Section headers, agenda | Skip | Skip |

### Step 1C: Transcript Signal Extraction (If Provided)

**Pass 1 — Extract Professor Signals:**

| Signal Type | What to Look For | How to Use |
|-------------|-----------------|------------|
| **Exam hints** | "This will be on the exam," "favorite question" | 🔴 RED TIER emphasis + guaranteed Anki card |
| **Emphasis** | Repeated concepts, "really important," "pay attention" | Weight more heavily |
| **Common mistakes** | "Students always get confused," "don't confuse X with Y" | Feed into Exam Traps |
| **Clinical pearls** | "In clinic," patient stories | Include in narrative |
| **De-emphasis** | "Don't worry about this," "just for reference" | Reduce coverage or skip |

**Pass 2 — Weight Content:**
- **Must-card:** Professor explicitly flagged for exam → 🔴 RED TIER
- **High-priority:** Significant time, clinical examples → standard bold
- **Standard:** Covered on slides, normal emphasis → standard bold
- **Low-priority:** Brief mention → consider skipping card
- **Skip:** Explicitly de-emphasized → no card

---

## PHASE 2: Study Guide Generation (.html)

### Why HTML, Not .docx

The study guide MUST be an interactive HTML file, not a flat Word document. This is non-negotiable because:

1. **Prediction prompts must be enforceable** — answers are hidden behind a click/tap toggle. In a .docx, the answer sits right below the question and the student will see it immediately. HTML solves this with collapsible elements.
2. **Tiered emphasis requires color** — .docx bold is binary; HTML supports background highlights for the professor-flagged tier.
3. **Teaching slides can be embedded inline** — images render naturally in HTML.
4. **The student opens it in any browser** — no software required.

### Study Guide HTML Structure

Generate a single self-contained .html file with embedded CSS and JavaScript. The file should:
- Be responsive (works on laptop, tablet, phone)
- Use clean, readable typography (system fonts, 18px body)
- Support dark mode via `prefers-color-scheme`
- Include all images as base64 or referenced from the same folder

**CSS classes for tiered emphasis:**
```css
.anki-card { font-weight: 700; }  /* Bold = this is an Anki card */
.professor-flagged { font-weight: 700; background-color: #FFF3CD; padding: 1px 4px; border-radius: 3px; }  /* Bold + yellow highlight = professor flagged for exam */
.precision-bridge { font-style: italic; color: #555; }  /* Italics = precision bridge */
.prediction-prompt { /* Collapsible answer section */ }
```

**JavaScript for prediction prompts:**
```javascript
// Each prediction prompt has a question visible and answer hidden
// Clicking "Reveal" shows the answer
// This ENFORCES the pause that prevents illusion of competence
function toggleAnswer(id) {
  var el = document.getElementById(id);
  el.style.display = el.style.display === 'none' ? 'block' : 'none';
}
```

### Tiered Visual Emphasis System

Three tiers, not binary bold/not-bold:

| Tier | Visual Treatment | Meaning | Density Cap |
|------|-----------------|---------|-------------|
| 🔴 **RED TIER** | **Bold + yellow highlight** | Professor flagged for exam. Guaranteed Anki card. STUDY THIS FIRST. | ≤10% of text |
| 🟡 **STANDARD TIER** | **Bold** | This concept has an Anki card. High-yield. | ≤30% of text |
| ⚪ **CONTEXT** | Regular text | Supporting explanation. Important for understanding but not directly carded. | Remainder |

**Bold Density Rule:** If more than 40% of any section's text is bolded (RED + STANDARD combined), you are over-carding that section. Go back and ask: which of these facts can be embedded inside an L2 relationship instead of being separately bolded?

### Study Guide Sections

#### Document Header
```html
<h1>[Lecture Title] — Study Guide</h1>
<h2>[Course Name] | [Date]</h2>
<div class="spacing-note">
  📅 <strong>Study Protocol:</strong> Read this guide today.
  Import the Anki deck. Do your first Anki review <strong>TOMORROW</strong>,
  not today. Sleeping on the material before retrieval practice
  dramatically improves long-term retention.
</div>
```

#### Part 1: Executive Summary

**Section A — The Big Picture (Narrative Primer)**

5-7 sentence plain-language narrative that:
- Explains the big idea in simple terms
- Describes what this topic is about conceptually
- Explains why it matters biologically and clinically
- Frames what you're about to learn and where the lecture is heading
- Includes at least one relatable hook (clinical scenario, everyday analogy)
- Feels like a brilliant upperclassman explaining it over coffee

**Section B — High-Yield Orientation**

6-8 concise bullets:
- Core framework of the lecture
- Most important mechanisms
- Main conceptual themes
- Clinical relevance
- Most testable ideas
- Professor signals (if transcript provided)

#### Part 2: Per-Objective Deep Dives

For EACH learning objective:

---

**A. The Story (Narrative with Integrated Mechanisms)**

3-5 paragraphs of engaging narrative. This is where mechanisms live — NOT in a separate section. Rules:

- Write in second person ("you") for immediacy
- Start with a hook — clinical scenario, "what if," surprising fact
- Build from simple to complex
- **Bold every concept that becomes an Anki card** (using tiered emphasis)
- Embed teaching slides at relevant moments: inline `<img>` tags
- Include precision bridges after every analogy:
  `<span class="precision-bridge">(Precisely: [exact terminology])</span>`
- Professor signals when available:
  `<span class="professor-flagged">📌 Professor emphasis: "[quote]"</span>`
- **Integrate mechanism chains INTO the narrative** as inline arrow chains, not a separate section:
  `gp120 binds CD4 → conformational change → V3 loop exposed → co-receptor binding → gp41 fusion`
- End with a clinical connection tying mechanism to real medicine
- Reference earlier sections when concepts connect:
  "Remember how we said gp120 works like a key in Section 1? That same two-step principle applies here..."

**ENFORCED PREDICTION PROMPTS (Critical):**

Before every major concept reveal, insert a prediction prompt with a HIDDEN answer:

```html
<div class="prediction-prompt">
  <p>🧠 <strong>Think about it:</strong> If CD4 binding alone were sufficient
  for entry, what would that mean for any cell with CD4? Why might the virus
  need a second step?</p>
  <button onclick="toggleAnswer('pred-1')">Reveal Answer</button>
  <div id="pred-1" style="display:none" class="prediction-answer">
    <p>If CD4 alone were enough, the virus would infect dendritic cells,
    some macrophages, and other CD4-expressing cells indiscriminately.
    The co-receptor requirement provides tissue tropism — the virus can
    "choose" which cells to enter based on whether they express CCR5 or
    CXCR4...</p>
  </div>
</div>
```

**Minimum:** 2-3 prediction prompts per learning objective. These must come BEFORE the answer, and the answer MUST be hidden.

**B. High-Yield Distinctions**

Side-by-side comparison tables for commonly confused concepts:

```html
<table class="distinction-table">
<tr><th>Feature</th><th>Concept A</th><th>Concept B</th></tr>
<tr><td>[Feature 1]</td><td>...</td><td>...</td></tr>
</table>
```

**C. The Memorization Bank**

Irreducible facts that become L1 Anki cards:

```html
<div class="memorization-bank">
📋 <strong>MEMORIZE:</strong>
<ul>
  <li><strong class="anki-card">[Term]</strong> — [one-line definition]</li>
  <li><strong class="anki-card">[Term]</strong> — [one-line definition]</li>
</ul>
</div>
```

**D. Exam Traps**

2-3 misconceptions:

```html
<div class="exam-trap">
  ⚠️ <strong>TRAP:</strong> [Misconception statement]<br>
  ✅ <strong>REALITY:</strong> [Correct statement]
</div>
```

---

**BRIDGING PARAGRAPHS (Between Every 2-3 Objectives):**

After every 2-3 objectives, insert a bridging paragraph that forces cross-objective connection:

```html
<div class="bridge">
  <h3>🔗 Connecting the Dots</h3>
  <p>Notice how the [mechanism from LO1] directly explains why [clinical
  finding from LO3] occurs. If you understand [concept A], you can
  <em>derive</em> [concept B] without memorizing it separately...</p>
</div>
```

This combats blocked practice by forcing interleaving within the study guide itself.

---

#### Part 3: Integration Section

**Top 10 Must-Know Facts**
Numbered, using RED TIER emphasis for professor-flagged items and STANDARD for the rest.

**Practice Questions (Vignette Taxonomy)**

12-18 questions that MUST follow these templates. No bare recall questions allowed:

**Template 1 — Clinical Vignette (Application)**
```
A [age]-year-old [sex] presents with [2-3 relevant symptoms].
[1-2 relevant physical exam/lab findings].
[Relevant history or risk factor].

Which of the following best explains [mechanism/finding/next step]?

A) [Distractor — common misconception from Exam Traps]
B) [Distractor — related but wrong mechanism]
C) [Correct answer]
D) [Distractor — true statement but doesn't answer the question]
E) [Distractor — opposite/confused concept from High-Yield Distinctions]

Answer: C
Explanation: [Why C is right AND why each wrong answer is wrong]
Maps to Anki card: [reference the specific card this tests]
```

**Template 2 — Mechanism Reasoning**
```
A researcher discovers that [experimental manipulation].
What is the most likely effect on [downstream process]?
```

**Template 3 — Cross-Objective Integration**
```
[Vignette that requires knowledge from LO1 AND LO3 to answer]
```
Minimum 3 questions must be cross-objective.

**Template 4 — "What Happens If" (Mutation/Inhibition)**
```
If [protein/gene/pathway] is [mutated/inhibited/overexpressed],
which of the following would be expected?
```

**Distractor Design Rules:**
- Every distractor must represent a SPECIFIC misconception
- At least one distractor should be a true statement that doesn't answer the question
- At least one distractor should come from the Exam Traps section
- No "all of the above" or "none of the above"
- Each question must map to a specific Anki card (stated after the explanation)

---

## PHASE 3: Card Generation (Derived from Study Guide)

### Critical Rule: Derived, Not Independent — AND Filtered by Yield

Every Anki card traces back to a bolded concept in the study guide. But NOT every bolded concept becomes a card. The study guide contains broader context; the Anki deck is filtered to LO-essential concepts only.

**Step 3A: List the Learning Objectives**

Before writing ANY cards, list all stated LOs. These are the ONLY targets for cards. Content that falls outside the LOs stays in the study guide for comprehension but does NOT generate cards.

**Step 3B: Derivation mapping (FILTERED)**
- **Bolded cause→effect phrase** in narrative → L2 card **IF it directly answers an LO**
- **Bolded key term** in Memorization Bank → L1 card **ONLY IF it cannot be embedded in an L2 and is essential for the LO**
- **Bolded process** in narrative's inline mechanism chain → L3 or L3-NR **ONLY IF the process itself is an LO target**
- **Exam Trap distinction** → L2 card **IF it corrects a misconception about an LO**
- **Prediction Prompt answer** → High-priority L2 card **IF it maps to an LO**

**Step 3C: Apply the Three Yield Tests to every candidate card**

Before writing each card, check:
1. ✅ **LO-Direct:** Does this card help answer a stated Learning Objective?
2. ✅ **Non-Redundant:** Is this concept NOT already covered by another card?
3. ✅ **Non-Derivable:** Can the student NOT derive this from another card they have?

If any test fails → the concept stays in the study guide only, no card.

**Step 3D: Count check**

After generating all cards, count them. If >35 per lecture hour, go back and cut the weakest. Ask: "If the student could only review 25 cards from this lecture, which 25 would give them the best LO coverage?"

**Step 3E: Slide-Content Verification (MANDATORY — Anti-Hallucination Check)**

After generating ALL cards, perform this verification for every single card:

1. **Read the slide** referenced in the SLIDE_NUM field (field 1).
2. **Confirm the card's core claim** is visually present on that slide (a diagram, text, data, image, or table that directly supports the cloze content).
3. **If the content is NOT on the referenced slide:** DELETE the card. Do not reassign it to a different slide unless you can confirm the content IS on that other slide.
4. **Output a verification table:**

```
SLIDE-CONTENT VERIFICATION:
  Card 1 → Slide X: ✅ [what on the slide confirms this card]
  Card 2 → Slide Y: ✅ [what on the slide confirms this card]
  Card 3 → Slide Z: ❌ DELETED — content not found on slide
  ...
```

**Common hallucination patterns to catch:**
- Card about a drug/trial not mentioned anywhere in the lecture slides
- Card with correct medical content that happens to not be in THIS lecture
- Slide number that actually shows a title/transition slide, not the claimed content
- Card referencing a figure/diagram from a different lecture or textbook
- Content from your medical training data that "fills in" gaps the professor chose not to cover

This step is NON-NEGOTIABLE. Skipping it caused catastrophic deck quality failures in past sessions.

### Breaking Analogy Dependence (Critical Design Choice)

The study guide and the card Extra field must NOT use the same analogy. This prevents pattern-matching instead of genuine retrieval.

| Location | Analogy Style | Purpose |
|----------|--------------|---------|
| **Study Guide** | Intuitive, everyday analogy | Build initial conceptual scaffold during first reading |
| **Card Extra (Conceptual Bridge)** | Clinical restatement with precision | Force translation between representations during retrieval |

**Example — HIV Entry:**

Study guide says:
> "gp120 works like a **key that morphs to reveal a second key** inside it"

Card Conceptual Bridge says:
> "CD4 binding alone is insufficient — it induces a conformational change in gp120 that exposes the V3 loop, which must engage a co-receptor (CCR5 or CXCR4) before gp41 can mediate fusion. This two-step gating is why entry inhibitors can target either step independently. *(The study guide called this the 'two-key system' — here's the precise mechanism.)*"

Note the final sentence: it REFERENCES the study guide analogy without repeating it. This creates a bridge between the intuitive and clinical frames without creating dependence on either one.

### AnKing-Style Card Format (Non-Negotiable)

This pipeline follows the AnKing formatting standard — the gold standard for medical school Anki.

#### Friend Voice for Cloze Sentences (Non-Negotiable)

Cloze sentence text must be written in **conversational "friend-told-you" voice** — the way a smart classmate would explain it over coffee. The cloze ANSWERS stay as precise medical terminology; only the surrounding sentence gets casualized.

**Why:** The wrapping sentence is read dozens of times during reviews. Formal textbook prose forces the brain to parse structure AND recall the answer. Conversational prose parses instantly, so all cognitive effort goes to the actual recall. Faster reviews, better retention, more enjoyable.

**Rules:**
1. **Cloze answers = exact medical terms** (never casualized): `{{c1::GAP-mediated GTP hydrolysis::blocked process}}`, `{{c1::t(9;22)::translocation}}`, `{{c1::missense::mutation type}}`
2. **Wrapping sentence = friend voice**: natural flow, dashes instead of semicolons, contractions OK, "here's the thing" / "turns out" / "that's why" / "basically" are all fine
3. **No dumbing down**: the friend is smart and uses the right words — they just don't talk like a textbook
4. **Relationship still present**: the sentence must still test a relationship (cause→effect, comparison, mechanism). The relationship is expressed through natural language flow (dashes, "so", "which means") rather than stiff connectors ("whereas", "therefore")

| ❌ Textbook voice (old style) | ✅ Friend voice (new style) |
|-----|------|
| `Oncogenes promote cancer through {{c1::gain-of-function}} mutations and are {{c2::dominant}} (one mutant allele sufficient), whereas tumor suppressor genes act through {{c1::loss-of-function}} mutations and are {{c2::recessive}} (both alleles must be lost)` | `Oncogenes are {{c1::gain-of-function}} and {{c2::dominant}} — one mutant copy is enough to drive cancer. Tumor suppressors are {{c1::loss-of-function}} and {{c2::recessive}} — you need to lose both copies before the brakes fail` |
| `The oncogenic RAS mutation at codon 12 ({{c1::Gly→Val}}) prevents {{c2::GAP-mediated GTP hydrolysis}}, locking RAS in the constitutively active GTP-bound state` | `The classic RAS mutation swaps codon 12 from {{c1::Gly→Val}}, and that blocks {{c2::GAP-mediated GTP hydrolysis}} — so RAS gets stuck permanently ON` |
| `CDK4/6 inhibitors (e.g., {{c1::palbociclib}}) are effective in cancers with {{c2::intact RB}} and elevated Cyclin D signaling because the drugs prevent RB phosphorylation, keeping E2F sequestered` | `CDK4/6 inhibitors like {{c1::palbociclib}} only work if the tumor still has {{c2::intact RB}} — because the whole point of the drug is to keep RB active. No RB? The drug has nothing to work with` |

**The test:** Read the card aloud. Does it sound like something you'd actually say to a classmate? If it sounds like a textbook sentence with blanks, rewrite it.

#### Cloze Answers: 1-3 Words (Critical)

Cloze answers are **single terms or very short phrases** — never sentences. The surrounding sentence provides all context. The student recalls a WORD, not a paragraph.

**Target: 1-3 words per cloze answer. Absolute max: 5 words.**

| Bad (old style) | Good (AnKing style) |
|-----|------|
| `{{c1::because ischemia removes O₂ AND removes nutrients AND prevents waste removal::metabolic consequences}}` | `Ischemia removes {{c1::O₂, nutrients, AND waste removal::what's lost}}` |
| `{{c1::REVERSIBLE replacement of one differentiated cell type with another::process definition}}` | `Metaplasia is {{c1::reversible::reversible or irreversible}} replacement of one cell type with another` |
| `{{c1::because mycobacterial lipid-rich cell wall resists digestion, creating cheese-like acellular debris::TB-specific mechanism}}` | `{{c1::Caseous::type}} necrosis is the hallmark of tuberculosis` |

**The rule:** The cloze hides the KEY TERM the student must recall. Everything else stays visible as context.

**Parenthetical context belongs INSIDE the cloze (Non-Negotiable):**

If the cloze term has a parenthetical that elaborates, defines, or gives examples, that parenthetical is part of the recall target and MUST be inside the cloze brackets.

| ❌ Wrong — parenthetical split off | ✅ Correct — parenthetical inside |
|-----|------|
| `{{c1::genetic::class}} (inherited or acquired mutations)` | `{{c1::genetic (inherited or acquired mutations)::class}}` |
| `{{c1::Totipotent::potency}} cells (zygote)` | `{{c1::Totipotent (zygote)::potency}}` |
| `{{c1::receptor tyrosine kinases::type}} (RTKs)` | `{{c1::receptor tyrosine kinases (RTKs)::type}}` |
| `{{c1::Labile::category}} cells divide continuously (skin, GI)` | `{{c1::Labile cells divide continuously (skin, GI, bone marrow)::category}}` |

The parenthetical is what makes the answer complete — recalling just "genetic" without knowing it means "inherited or acquired mutations" is incomplete recall.

**BUT: Never stuff an entire description into a single cloze (Non-Negotiable):**

Each cloze tests ONE key term. The sentence provides context. If a card compares multiple categories, each category name is its own short cloze — the description stays visible.

| ❌ Wrong — mega-cloze | ✅ Correct — short clozes, visible context |
|-----|------|
| `{{c1::Labile cells divide continuously (skin, GI, bone marrow)::category}}` | `{{c1::Labile::category}} cells divide {{c4::continuously (skin, GI, bone marrow)}}` |
| `{{c1::stable cells regenerate when stimulated::category}}` | `{{c1::stable::category}} cells regenerate when stimulated` |

The test: when the cloze is hidden, is there enough visible sentence structure to cue recall? If hiding the cloze leaves just a blank with no context → you've put too much inside.

#### Extra Field: "High School Explanation" (3-4 Sentences)

The Extra field is a plain-language explanation of the concept — written like a smart friend explaining it over coffee. It's the safety net: when you see the answer and it doesn't fully click, you read the Extra and it makes sense. When you already know it, you skip it entirely.

**Tone:** Casual, clear, intuitive. No jargon without explanation. No textbook voice.

**Formula:** What's happening → Why it happens → Why it matters clinically → How it connects to the LO (3-4 sentences)

**Examples:**
```
When a tissue loses blood supply, it's not just losing oxygen — it's also losing the nutrients cells need to make ATP AND the ability to flush out waste like lactic acid. That triple hit is why a heart attack (ischemia) kills tissue way faster than just low oxygen (like being at high altitude). Hypoxia is bad; ischemia is catastrophic.
```
```
Think of it this way: necrosis is a cell exploding — all its guts spill out and the immune system freaks out (inflammation). Apoptosis is a cell quietly packing itself into neat little bags that get eaten by neighbors before anything leaks. That's why necrotic tissue gets red and swollen but apoptosis happens silently.
```
```
The liver is basically a fat-processing factory. When more fat comes in than it can burn or ship out (as VLDL), the excess just piles up inside liver cells as triglyceride droplets. Alcohol, obesity, and malnutrition can all overwhelm the system. The good news: it's reversible if you remove the cause. The bad news: if you don't, it can progress to inflammation (steatohepatitis) and eventually cirrhosis.
```

**Rules:**
- 3-4 sentences, plain language
- Explain the "why" — don't just restate the fact from the cloze
- Include a clinical connection or "so what" when possible
- **Last sentence must explicitly connect to the Learning Objective** — explain WHY this card matters for the LO. This anchors the card to a purpose and helps the student prioritize during review.
- Use analogies sparingly and only if they genuinely help
- NO formal headers, labels, or structured sections — just flowing explanation

**What NOT to write:**
- ❌ Restating what the cloze already says
- ❌ Textbook-voice paragraphs with jargon
- ❌ Structured sections with bold labels (Common Error, Clinical Anchor, etc.)
- ❌ Extra fields that don't explicitly reference the Learning Objective
- ❌ Anything longer than 4 sentences — if you need more, the study guide has it

### Target Distribution

**Total: 25-35 cards per lecture hour** (hard cap)

| Level | Target % | Role | Typical Count |
|-------|----------|------|---------------|
| **L2** | **70–85%** | PRIMARY — relationships, mechanisms, discriminators | 20-28 |
| **L1** | 5–15% | Support — ONLY truly irreducible facts that cannot live in an L2 | 2-5 |
| **L3 / L3-NR** | 5–10% | Synthesis — genuine processes, pathways, cascades only | 1-2 |

**Why L1 dropped to 5-15%:** Most "facts" can and should be embedded in L2 relationships. A standalone L1 card for "pyknosis" is wasted when an L2 card already tests "nuclear changes in necrosis: pyknosis → karyorrhexis → karyolysis." The L2 card forces retrieval of the fact AND the relationship. Only make an L1 when the fact is genuinely irreducible (classic lists like cardinal signs, pathognomonic findings, drug names).

### Card Level Definitions

#### L2 — Integration (PRIMARY, 70-85%)

Tests a **relationship, mechanism, or discriminator**. Requires ≥2 clozes.

**AnKing-style pattern:** The sentence provides the relationship context; clozes hide KEY TERMS (1-3 words each). Relationship words (because, whereas, etc.) stay VISIBLE — they're context, not the answer.

**Difficulty calibration:**
- **Standard L2:** 2 clozes — bread and butter
- **Complex L2:** 3 clozes — use sparingly
- **4+ clozes:** SPLIT into two cards. Cognitive overload during review.

**Examples (AnKing style):**
```
NRTIs lack a {{c1::3'-OH group::chemical group}}, causing {{c2::chain termination::effect}}

{{c1::Coagulative::type}} necrosis preserves architecture; {{c2::liquefactive::type}} necrosis destroys it completely

Bcl-2 is anti-apoptotic because it {{c1::blocks BAX/BAK::mechanism}} pore formation; cancer cells overexpress Bcl-2 to {{c2::evade apoptosis::survival advantage}}
```

**Notice:** Each cloze answer is 1-3 words. The sentence does the teaching; the cloze tests recall.

#### L1 — Support Facts (HIGHLY SELECTIVE, 5-15%)

**Before creating ANY L1 card, ask:** "Can this fact be embedded in an L2 relationship?" If yes → embed it in the L2 and do NOT create a separate L1. Only ~2-5 L1 cards per lecture should survive this filter.

**MANDATORY FORMAT:**
```
{{c1::[ANSWER]::[HINT]}} | [KEY DISTINGUISHING FEATURE OR CLINICAL CONTEXT]
```

**Format templates by content type:**
- Organisms: `{{c1::[NAME]::[Category]}} | [KEY FEATURE]`
- Drugs: `{{c1::[DRUG]::Drug}} | [CLASS or MECHANISM]`
- Diseases: `{{c1::[DISEASE]::Condition}} | [PATHOGNOMONIC FINDING]`
- Signs: `{{c1::[SIGN]::Clinical sign}} | [WHAT IT INDICATES]`
- Anatomy: `{{c1::[STRUCTURE]::Structure}} | [LOCATION or FUNCTION]`
- Numbers: `{{c1::[VALUE]::Range/Number}} | [CLINICAL CONTEXT]`

**L1 Test:** "Can this fact be embedded in a relationship?" If yes → L2.

**Edge case:** Bidirectional associations use 2 clozes:
`{{c1::[ANSWER]::[HINT]}} is the first-line treatment for {{c2::[CONDITION]::[hint]}}`

#### L3 — Process Scaffold (5-10%)

2-8 clozes, sequential steps. Only genuine multi-step processes.

**Calibration:** 2-4 clozes = good; 5-6 = dense; 7-8 = max, split if more needed.

#### L3-NR — Narrative Recall

Basic card (Front → Back), NO clozes. Only for true temporal/logical sequences.

**Grading rubric (include on the BACK of every L3-NR card):**
```
<div class="grading-guide">
<b>How to grade:</b><br>
Again = fewer than half the steps or wrong order<br>
Hard = most steps, missed 1-2 details<br>
Good = all major steps in order<br>
Easy = every step with details, first try
</div>
```

This rubric goes ON the card itself, not just in the skill documentation.

### Cloze Rules (Strict)

#### All Clozes Require Hints
```
{{c1::answer::hint}}     ← CORRECT
{{c1::answer}}           ← WRONG
```

#### No Redundant Hints (Non-Negotiable)

If the hint word already appears **immediately adjacent** to the cloze in the visible sentence, the hint is redundant and gives the answer away for free. Either use a different hint or omit the hint if the surrounding sentence provides enough context.

| ❌ Wrong — redundant hint | ✅ Correct — no giveaway |
|-----|------|
| `{{c1::ubiquitin-proteasome::pathway}} pathway` | `{{c1::ubiquitin-proteasome}} pathway` |
| `{{c1::liver::organ}} is an organ that...` | `{{c1::liver::abdominal organ}} is an organ that...` |
| `{{c1::apoptosis::death}} is a form of cell death` | `{{c1::apoptosis}} is a form of cell death` |

**The test:** Read the sentence with the cloze hidden. Does the hint duplicate a word the student can already see right next to the blank? If yes → the hint is free points, not a learning aid. Either pick a different hint that tests from a different angle, or drop the hint entirely when the surrounding sentence already scaffolds recall.

#### Hint Type Taxonomy

| Scenario | Hint Format | Example |
|----------|-------------|---------|
| Binary choice | ::option A or option B | {{c1::dorsal::dorsal or ventral}} |
| Category | ::category name | {{c1::acetylcholine::neurotransmitter}} |
| Quantity | ::unit or type | {{c1::70%::percent}} |
| Structure/layer | ::layer | {{c1::epineurium::layer}} |
| Cell type | ::cell type | {{c1::oligodendrocyte::cell type}} |
| Drug/molecule | ::drug | {{c1::Maraviroc::drug}} |
| Receptor/protein | ::receptor | {{c1::CCR5::co-receptor}} |
| Disease/condition | ::condition | {{c1::Multiple sclerosis (MS)::disease}} |
| Location | ::location | {{c1::PNS::location}} |
| Timing | ::timing | {{c1::early infection::timing}} |
| Mechanism/effect | ::effect | {{c2::chain termination::effect}} |
| Clinical outcome | ::clinical outcome | {{c2::not respond::clinical outcome}} |

#### Cloze Numbering
| Scenario | Rule |
|----------|------|
| Binary comparison (A is X while B is Y) | SAME number (c1, c1) |
| Independent facts | DIFFERENT numbers |
| Cause → effect | c1 = cause, c2 = effect |

#### Abbreviation Rule
`✅ {{c1::Multiple sclerosis (MS)::disease}}` — abbreviation INSIDE cloze
`❌ {{c1::Multiple sclerosis::disease}} (MS)` — abbreviation outside

#### Quantity Rule
`✅ {{c1::70%::percent}} lipids` — unit WITH number
`❌ {{c1::70::percent}}% lipids` — unit outside

### Mnemonic Framework

Optional. Preferred types (in order):

| Type | Example |
|------|---------|
| Etymology | "Epi = upon → outermost layer" |
| Acronym | "SOAP: Subjective, Objective, Assessment, Plan" |
| Visual association | "Endo = within = individual candy wrappers" |
| Phonetic link | "MaraVIROC = VIRus + blROCk" |
| Contrast pair | "SchwONE = ONE axon" |

One line max. No forced mnemonics. For L2 cards, etymology built into the relationship often suffices.

### Output Format: Flashcards.txt

```
SLIDE_NUM|LEVEL|Cloze text|Conceptual Bridge|Learning Objective|Mnemonic (optional)
```

**Learning Objective Field — VERBATIM (Non-Negotiable):**

The Learning Objective field must contain the **exact text** of the stated Learning Objective from the lecture, copied verbatim. Do NOT paraphrase, abbreviate, or invent sub-labels.

| ❌ Wrong | ✅ Correct |
|----------|-----------|
| `LO1: Anatomic vs mechanistic classification` | `Describe anatomic versus mechanistic classification of diseases` |
| `LO4: Stem cell niche` | `Describe tissue homeostasis and the role of stem cells` |
| `LO2: Etiology vs pathogenesis example` | `Discuss the difference between etiology and pathogenesis of disease` |

Multiple cards mapping to the same LO will have the **identical** LO string. Never invent sub-LOs.

### Formatting Rules (HTML Only in Cards — No Markdown)

- `<b>bold</b>` not `**bold**`
- `<i>italics</i>` not `*italics*`
- `<br>` for line breaks
- `•` for bullets

---

## PHASE 4: Pipeline & Delivery

### Step 4A: Generate Study Guide (.html)

Create a self-contained HTML file with embedded CSS, JavaScript, and images.

### Step 4B: Generate Anki Deck (.apkg)

```bash
pip install genanki pdf2image python-pptx pillow --break-system-packages
python scripts/anki_pipeline_v2_1.py \
  --slides lecture.pdf \
  --cards Flashcards.txt \
  --output Deck.apkg \
  --name "StanfordMed - [Lecture Name]"
```

### Step 4C: Verify Coverage & Yield

- Every LO has a study guide section
- Every LO has Anki cards
- **Total card count: 25-35 per lecture hour** (hard cap)
- **Yield filter applied:** every card passes LO-Direct + Non-Redundant + Non-Derivable tests
- Bold density: no section exceeds 40% (study guide can bold more than gets carded)
- Prediction prompt count: minimum 2-3 per LO
- Analogy independence: no card Extra field copies study guide analogy verbatim
- **L1 count check:** if >5 L1 cards, review whether any can be embedded in L2s

### Step 4D: Deliver with Spacing Instruction

User receives:
1. `[Lecture]_StudyGuide.html` — Read this TODAY
2. `[Lecture]_Flashcards.apkg` — Import to Anki, first review TOMORROW
3. Explicit spacing instruction in the delivery message:

```
📅 STUDY PROTOCOL:
1. Read the study guide now (takes ~[X] minutes)
2. Import the .apkg into Anki
3. Do your FIRST Anki review TOMORROW — not today
4. Sleeping on new material before retrieval practice is one of the
   strongest findings in memory research. The delay is not laziness;
   it's the protocol.
```

### Summary Block

```
================================================================================
SUMMARY
================================================================================
Study Guide: [filename].html | ## pages | ~## min read time
  Prediction prompts: ## (enforced with hidden answers)
  Bridging paragraphs: ##
  Practice questions: ## (## cross-objective)
  Bold density: ##% (target: ≤40%)

Anki Deck: [filename].apkg
  Total cards: ## (target: 25-35 per lecture hour)
  • L2 integration: ## (##%) ← Target: 70-85%
  • L1 support facts: ## (##%) ← Target: 5-15%
  • L3/L3-NR process: ## (##%) ← Target: 5-10%

Yield Filter Results:
  Cards generated before filter: ##
  Cards after yield filter: ##
  Cards cut: ## (reasons: ## redundant, ## derivable, ## outside LO)

Alignment Checks:
  ✅ LO field: every card uses VERBATIM Learning Objective text (no paraphrasing or sub-labels)
  ✅ Yield filter: every card passes LO-Direct + Non-Redundant + Non-Derivable
  ✅ Analogy independence: no Extra field copies study guide verbatim
  ✅ AnKing cloze style: all cloze answers 1-3 words, context in surrounding sentence
  ✅ Extra field: 3-4 sentence plain-language explanation per card
  ✅ L3-NR grading rubric: included on every L3-NR card
  ✅ L1 check: ≤5 L1 cards, all truly irreducible

LO Coverage:
  ✅ LO1: [title] — Guide section ✓ | ## cards
  ✅ LO2: [title] — Guide section ✓ | ## cards
  ...

Professor Signals: ## exam hints (🔴), ## emphasis, ## de-emphasis
================================================================================
```

---

## PHASE 5: Week 1 Review Protocol (On Request)

After 5-7 days of Anki reviews, the student can request a Week 1 Review.

### Input
Student provides:
- List of leech cards (cards they keep failing)
- Any cards that felt confusing or poorly worded
- Any concepts where the Conceptual Bridge didn't help

### Process
1. **Identify failure patterns:** Are the leeches clustered in one LO? One card level? One concept type?
2. **Diagnose the problem:**
   - If the student keeps failing L2 cards → the relationship wasn't clear in the study guide narrative. Rewrite that section.
   - If the student keeps failing L1 cards → the fact may need a relationship to anchor it. Promote to L2 with a mechanism.
   - If the Conceptual Bridge isn't helping → the clinical restatement may be too abstract. Add a more concrete clinical scenario.
3. **Regenerate affected cards** with new framing
4. **Update the study guide section** if the narrative was unclear
5. **Deliver a patch:** new cards to import (replacing the old ones) + revised study guide section

### Output
```
WEEK 1 REVIEW REPORT
================================================================================
Leech cards analyzed: ##
  • Rewritten with new framing: ##
  • Promoted L1→L2 (added relationship): ##
  • Conceptual Bridge rewritten: ##
  • Study guide section revised: ##

Root cause analysis:
  [Pattern identified and what was changed]
================================================================================
```

---

## Pipeline Configuration

### Anki Note Type: 02 Stanford Med (Cloze)

**Model ID:** `1756357830009`

**Fields (all Arial, size 20):**
1. Text
2. Extra (Conceptual Bridge)
3. LearningObjective
4. Images
5. Mnemonics

**Front Template:**
```html
<div class="front">
{{cloze:Text}}
</div>

<script type="module" src="https://content-gateway.us.production.amboss.com/amboss.js" data-addon="eyJhbm9uSWQiOiAiOGZmMmJlOTMtNTBhNy00MTc4LTgzMWItZjQ5N2NlNzNiZTIwIiwgInVzZXJJZCI6ICJTcTBTYXlCU3lQIiwgInRva2VuIjogImV5SmhiR2NpT2lKU1V6VXhNaUlzSW5SNWNDSTZJa3BYVkNKOS5leUpsZUhBaU9qRTNOekF4TURReU1EWXNJbWx6Y3lJNklrRk5RazlUVXlJc0luTjFZaUk2SWxOeE1GTmhlVUpUZVZBaUxDSnBZWFFpT2pFM05qYzFNVEl5TURaOS5rcHZHa2FUc1dYcDMxaVlZNENwYjJ6emFTWktMUGl5V1RzX3lRTjNBQUY2UnU2N2FiT1JVeTZTUnYzcFhHT1JjWHBjTXJCUjBQdXZWS2R4c2VDOFQza0NpcGxXQWRHRnhXaGotV3p5VDZYdk83SjN6RDJqby1WMjMwM3MxWlExSkQ1UzVaSmZ6Z0RrdFNkQTVjWHhTdWZrdmJXVHVqV3dZX21pM1NVVUxtdm9xX2VTYmhGY2dod1lLTXpJV3BJMHFSOTlTTWVVN3FsRWJYWUF4UU5qcG12aWU0VHBXOEZ4T3VMRnQ1LUN5el9zYWc5MGttZ2QySVU4cFlEWURCMGtOR1BnaHlvcjZvOFZaOXdQcHpkT3cwQ29WYjg5LUdWTVJCN3d3SDl4WkkyM0V4Nkk5VGRSczUzMHBkTVg4Qk8zQ1U2S3lycl9DdDlGQXpMUmV5N2JFYlEifQ==" id="amboss-snippet"></script>
```

**Back Template:**
```html
<div class="front">
{{cloze:Text}}
</div>

{{#Extra}}
<hr>
<div class="back">
{{Extra}}
</div>
{{/Extra}}

{{#Images}}
<div class="image">
<h3>Images</h3>
{{Images}}
</div>
{{/Images}}

{{#Mnemonics}}
<div class="mnemonics">
<h3>Mnemonics</h3>
<p>{{Mnemonics}}</p>
</div>
{{/Mnemonics}}

{{#LearningObjective}}
<div class="learning-objective">
<h3>Learning Objective</h3>
<p>{{LearningObjective}}</p>
</div>
{{/LearningObjective}}

{{#Tags}}
<div class="tags" id="tag-container">
{{Tags}}
</div>
<script>
(function() {
var tagContainer = document.getElementById("tag-container");
if (tagContainer) {
var rawTags = tagContainer.innerText.trim().split(/\s+/);
tagContainer.innerHTML = "";
rawTags.forEach(function(tag) {
var span = document.createElement("span");
span.textContent = tag;
tagContainer.appendChild(span);
});
}
})();
</script>
{{/Tags}}

<script type="module" src="https://content-gateway.us.production.amboss.com/amboss.js" data-addon="eyJhbm9uSWQiOiAiOGZmMmJlOTMtNTBhNy00MTc4LTgzMWItZjQ5N2NlNzNiZTIwIiwgInVzZXJJZCI6ICJTcTBTYXlCU3lQIiwgInRva2VuIjogImV5SmhiR2NpT2lKU1V6VXhNaUlzSW5SNWNDSTZJa3BYVkNKOS5leUpsZUhBaU9qRTNOekF4TURReU1EWXNJbWx6Y3lJNklrRk5RazlUVXlJc0luTjFZaUk2SWxOeE1GTmhlVUpUZVZBaUxDSnBZWFFpT2pFM05qYzFNVEl5TURaOS5rcHZHa2FUc1dYcDMxaVlZNENwYjJ6emFTWktMUGl5V1RzX3lRTjNBQUY2UnU2N2FiT1JVeTZTUnYzcFhHT1JjWHBjTXJCUjBQdXZWS2R4c2VDOFQza0NpcGxXQWRHRnhXaGotV3p5VDZYdk83SjN6RDJqby1WMjMwM3MxWlExSkQ1UzVaSmZ6Z0RrdFNkQTVjWHhTdWZrdmJXVHVqV3dZX21pM1NVVUxtdm9xX2VTYmhGY2dod1lLTXpJV3BJMHFSOTlTTWVVN3FsRWJYWUF4UU5qcG12aWU0VHBXOEZ4T3VMRnQ1LUN5el9zYWc5MGttZ2QySVU4cFlEWURCMGtOR1BnaHlvcjZvOFZaOXdQcHpkT3cwQ29WYjg5LUdWTVJCN3d3SDl4WkkyM0V4Nkk5VGRSczUzMHBkTVg4Qk8zQ1U2S3lycl9DdDlGQXpMUmV5N2JFYlEifQ==" id="amboss-snippet"></script>
```

**CSS (Light + Dark Mode):**
```css
.card {
font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
font-size: 18px; text-align: center; color: #2E2D29;
background-color: #FAFAFA; padding: 28px; border-radius: 14px;
border: 1px solid #CFCFCF; max-width: 900px; margin: auto;
}
.front { font-size: 22px; font-weight: 600; color: #000000; margin-bottom: 15px; }
.back { font-size: 22px; font-weight: 400; color: inherit; margin-top: 15px; line-height: 1.5; }
.cloze { color: #0090FF; background-color: #E8E8E8; padding: 2px 6px; border-radius: 4px; font-weight: 600; }
.cloze:hover { background-color: #FCFCFC; }
.image, .mnemonics, .learning-objective {
margin-top: 20px; padding: 12px; text-align: left; border-radius: 6px;
background-color: #EDEDED; border-left: 3px solid #8C1515;
}
.image h3, .mnemonics h3, .learning-objective h3 { font-size: 18px; color: #8C1515; margin: 0 0 8px 0; }
.image img { max-width: 100%; border-radius: 6px; box-shadow: 0 2px 6px rgba(0,0,0,0.2); display: block; margin: 8px 0; }
.mnemonics p, .learning-objective p { font-size: 18px; line-height: 1.4; color: #2E2D29; }
.tags { margin-top: 30px; display: flex; flex-wrap: wrap; justify-content: center; gap: 8px; }
.tags span { background-color: #EEE; color: #444; font-size: 14px; font-weight: 500; padding: 4px 10px; border-radius: 4px; }
body.nightMode .card { background-color: #222; color: #E4E4E4; box-shadow: 0 6px 16px rgba(0,0,0,0.6), 0 0 12px rgba(0,0,0,0.3); }
body.nightMode .front, body.nightMode .back { color: #E4E4E4; }
body.nightMode .cloze { color: #1C1C1C; background-color: #BFBFBF; }
body.nightMode .image, body.nightMode .mnemonics, body.nightMode .learning-objective { background-color: #2A2A2A; border-left: 3px solid #E57373; color: #F0F0F0; }
body.nightMode .image h3, body.nightMode .mnemonics h3, body.nightMode .learning-objective h3 { color: #E57373; }
body.nightMode .mnemonics p, body.nightMode .learning-objective p { color: #F0F0F0; }
body.nightMode .tags span { background-color: #444; color: #E0E0E0; }
.grading-guide { margin-top: 15px; padding: 10px; background: #f0f0f0; border-radius: 6px; font-size: 14px; text-align: left; }
body.nightMode .grading-guide { background: #333; }

/* Conceptual Bridge wrapper */
.conceptual-bridge { margin-bottom: 10px; line-height: 1.6; }
```

### Basic Card Model (for L3-NR)

**Model ID:** `1756357830010`
**Fields:** Front, Back, LearningObjective, Images
Same CSS. Pipeline routes L3-NR automatically. **Include grading rubric in Back field.**

### Pipeline Script

Located at `scripts/anki_pipeline_v2_1.py`.

**Requirements:** `pip install genanki pdf2image python-pptx pillow --break-system-packages`

### Tag Strategy

Automatic: `Level::L1-Atomic`, `Level::L2-Integration`, `Level::L3-Process`, `Level::L3-NarrativeRecall`
Deck naming: `StanfordMed - [Course] - [Lecture Name]`

---

## Quick Decision Tree

```
Can this concept be connected to another with a relationship?
├── YES → L2 (use relationship word)
│         This is your DEFAULT choice
│
└── NO → Is this a true multi-step process/sequence?
         ├── YES → L3 or L3-NR
         │
         └── NO → Is this truly irreducible?
                  ├── YES → L1 (mandatory format with hint + pipe)
                  └── NO → Don't card it, or find a relationship
```

---

## Cross-Reference Protocol (If Board Material Provided)

- ≥3 sentences or full mechanism in boards → skip card (redundant)
- ≤1 sentence in boards → keep (shallow coverage)
- ZERO board coverage → definitely keep (lecture-unique)
- Lecture has different/deeper angle → keep (unique perspective)

Per-LO, not global.

---

## DO / DON'T Checklist

**DO:**
- Generate study guide FIRST as interactive HTML, then derive cards
- Use enforced prediction prompts (hidden answers, click to reveal)
- Use tiered emphasis (🔴 highlight + 🟡 bold + ⚪ regular)
- Cap bold density at 40% per section
- Use different analogy framing: intuitive in guide, clinical in card
- Include spacing instruction: "Review tomorrow, not today"
- Add bridging paragraphs between every 2-3 objectives
- Write practice questions as clinical vignettes with designed distractors
- Integrate mechanism chains into narrative (no standalone section)
- Use "Conceptual Bridge" framing (not "High School Explanation")
- Use VERBATIM Learning Objective text from the lecture — never paraphrase or invent sub-labels
- Keep cloze answers to 1-3 words (AnKing style) — sentence provides context, cloze tests the KEY TERM
- Write Extra field as 3-4 sentence "high school explanation" — plain language, casual, the safety net when a concept doesn't click
- Include grading rubric ON every L3-NR card
- Support Week 1 Review for leech card iteration
- Map every practice question to a specific Anki card
- Write cloze wrapping sentences in friend voice — conversational, natural, like a smart classmate explaining it

**DO NOT:**
- Use identical analogies in study guide and card Extra field
- Put prediction prompt answers visible on the same screen as the question
- Exceed 40% bold density in any section
- Write bare recall questions (use vignette templates)
- Create standalone mechanism map sections (integrate into narrative)
- Tell students to review Anki immediately after reading (enforce spacing)
- Skip bridging paragraphs between objectives (prevents blocked practice)
- Write Extra fields longer than 4 sentences or in textbook voice — keep it casual and concise
- Put multi-word explanations inside cloze brackets — cloze answers should be 1-3 words
- Paraphrase or abbreviate Learning Objectives — always copy verbatim from the lecture
- Default to L1 for everything
- Create clozes without hints
- Use hints that duplicate a word already visible right next to the cloze (e.g., `{{c1::X::pathway}} pathway` — the student sees "pathway" twice)
- Use Markdown in Anki cards
- Make the study guide longer than 15 pages per lecture hour
- Write cloze wrapping sentences in textbook/formal voice — no "whereas", "therefore", or stiff academic prose around the clozes

---

*Medical Lecture Study Pipeline v5.7 — Friend-voice cloze sentences, AnKing-style clozes (1-3 word answers), lean Extra fields (3-4 sentences), enforced retrieval, spacing protocol, interleaved practice, tiered emphasis, vignette-based questions, integrated mechanisms, high-yield filter, feedback loops, bold density caps, no-redundant-hints rule, and parenthetical-inside-cloze rule.*
