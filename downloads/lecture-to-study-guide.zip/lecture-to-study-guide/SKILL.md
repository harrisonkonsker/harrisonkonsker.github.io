---
name: lecture-to-study-guide
description: >
  Convert a medical lecture (PDF + learning objectives) into a premium-formatted Word study guide.
  Use this skill whenever the user uploads a lecture PDF and asks for a study guide, asks to
  "build a study guide," "make a study guide," wants a "lecture-to-study-guide" conversion,
  or wants a polished .docx with callouts, tables, and tiered emphasis. Outputs a .docx with
  Calibri headers, Arial body, cardinal-red accent, MEMORIZE / EXAM TRAP callout boxes,
  comparison tables, and a Big Picture overview. Anti-hallucination: every fact must come
  from the user's lecture slides or stated LOs — no board knowledge.
---

# Lecture → Premium Study Guide

This skill produces a single deliverable: a polished `.docx` study guide for a medical lecture, in the Stanford SOM 221 premium format.

## When to use this skill

Trigger phrases:
- "build a study guide for [lecture]"
- "make a study guide from this PDF"
- "lecture to study guide"
- "study guide creator"
- "convert this lecture to a study guide"

Do NOT use this skill for: Anki cards alone (use `anki-flashcard-creator`), practice quizzes alone, or non-medical documents.

## Output

`<Lecture>_Study_Guide.docx` saved to the user's selected workspace folder, inside `Study/` if the lecture has its own subfolder.

## Anti-hallucination rule (overrides everything else)

**Every fact, drug name, mechanism, statistic, trial name, and clinical detail in the study guide must come from a slide in the user's lecture PDF or a verbatim learning objective.** No board knowledge. No supplementary content from training data. If a concept is not visually on a slide, it does not exist for this skill — even if you know it's medically correct.

If the user has not uploaded a PDF, ask for one before starting.

## Workflow

### Step 1 — Read every slide, build a slide map

Read the lecture PDF page by page. Produce a numbered slide-by-slide content summary:

```
SLIDE MAP:
  Slide 1: [1-line description of what's on the slide]
  Slide 2: [1-line description]
  ...
```

Locate the Learning Objectives slide (usually slides 2-5). Copy each LO **verbatim**. Do not paraphrase. If no LO slide exists, ask the user to provide LOs before proceeding.

### Step 2 — Build the deck JSON

Construct a JSON object matching the schema below. Save it to a working file (e.g., `<lecture>.json`).

```json
{
  "lecture": "<exact lecture name>",
  "course": "<e.g., SOM 221: Pulmonary Block>",
  "los": {
    "LO1": "verbatim text from slide",
    "LO2": "verbatim text from slide",
    ...
  },
  "big_picture": "5-7 sentence narrative primer in plain language. Explain the big idea, why it matters, and where the lecture is heading. Include one relatable hook (clinical scenario or everyday analogy). Should feel like a brilliant upperclassman explaining over coffee.",
  "orientation": [
    "Bullet 1 — most important framework concept",
    "Bullet 2 — second key concept",
    ...
    (6-8 bullets total)
  ],
  "sections": [
    {
      "lo": "LO1",
      "title": "Optional italic subhead capturing the lens for this LO",
      "narrative": "Multi-paragraph prose with **bold** key terms and __highlight__ for must-not-miss concepts. Use \\n\\n between paragraphs. Build from simple to complex. Reference earlier sections when concepts connect.",
      "memorize": [
        {"term": "Bold term", "def": "one-line definition"},
        {"term": "Another term", "def": "..."}
      ],
      "traps": [
        {"trap": "Common misconception statement", "reality": "Correct statement"},
        ...
      ]
    },
    ...
  ],
  "top10": [
    "Top fact 1 (use **bold** and __highlight__ for emphasis)",
    "Top fact 2",
    ...
    (8-10 items)
  ],
  "cards": [
    {"lo": "LO1", "text": "Cloze sentence with {{c1::answer::hint}}", "extra": "3-4 sentence conceptual bridge", "mnemonic": "", "image": ""},
    ...
  ]
}
```

**Inline emphasis tiers in narrative text:**
- `__word__` → bold + yellow highlight (🔴 must-not-miss / professor-flagged)
- `**word**` → bold (🟡 Anki concept / important term)
- plain text → context

Density caps: ≤30% bold, ≤10% highlight.

### Step 3 — Optional: extras (comparison tables)

If the lecture has matrix-shaped content (organism comparisons, drug tables, etc.), build an `extras` dict:

```python
extras = {
    "tables": {
        "LO2": [
            {
                "title": "Endemic fungi 5-way matrix",
                "headers": ["Organism", "Region", "Tissue form", "Clinical", "Host"],
                "rows": [
                    ["**Coccidioides**", "SW USA", "**Spherule + endospores**", "Valley Fever", "Filipino/AA"],
                    ...
                ],
            },
        ],
    },
    "master_tables": [
        {"title": "...", "headers": [...], "rows": [...]},
    ],
}
```

Tables get dropped inline after the matching LO's narrative. Master tables appear in Part 3.

### Step 4 — Render

```python
from scripts.build_premium_study_guide import render_premium
from pathlib import Path
import json

data = json.loads(Path("<lecture>.json").read_text())
out = Path("<workspace>/Study/<Lecture>_Study_Guide.docx")
out.parent.mkdir(exist_ok=True)
render_premium(data, out, extras=extras)
```

### Step 5 — Verify

Open the .docx and confirm:
- Title block + Study Protocol banner present
- Part 1 with Big Picture (blue band) + Orientation bullets (cardinal dots)
- Each LO has: LO header → narrative → MEMORIZE callout → EXAM TRAPS table
- Tables render with cardinal header row + alternating row shading
- Top 10 + Anki preview in Part 3

If any LO lacks a section, go back to the slides and fill it in. Do not invent content.

## Format spec (full)

The detailed spec — every font, color, callout, anti-pattern — is in `reference/format_spec.md`. Read it before modifying the renderer.

## Files in this skill

- `SKILL.md` — this file
- `scripts/build_premium_study_guide.py` — the renderer (don't modify without updating the spec)
- `scripts/enrich_emphasis.py` — apply `**bold**` / `__highlight__` markers to a deck JSON automatically using term-list heuristics
- `reference/format_spec.md` — canonical format specification (fonts, colors, structure)
- `examples/tuberculosis_and_fungal_infections.json` — full worked example

## Common errors to avoid

- **Forgetting to extract verbatim LOs** — paraphrased LOs break the lecture-anchored structure
- **Bold density >40% in any section** — the eye stops seeing emphasis
- **Putting comparison content in prose when a table would be clearer** — endemic fungi, drug mechanisms, ECG findings, etc. should be tables
- **Skipping MEMORIZE/EXAM TRAPS callouts** when the data has them
- **Using HTML tags** (`<b>...</b>`) in narrative text — only Anki cards use HTML; the docx renderer uses `**...**` markers
- **Producing the old plain-paragraph format** — that's the deprecated style, do not produce it

## Pipeline integration

If the user also wants an Anki deck (.apkg) for the same lecture, use `anki-flashcard-creator` after this skill. The deck JSON's `cards` field is already compatible with the AnKing Stanford Med Cloze notetype.

If the user wants a practice quiz with per-choice rationales, that's a separate v3 builder — not part of this skill.
